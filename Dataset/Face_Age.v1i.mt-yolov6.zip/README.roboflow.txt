
Face_Age - v1 2022-06-24 12:16pm
==============================

This dataset was exported via roboflow.ai on July 12, 2022 at 3:05 PM GMT

It includes 102 images.
Age are annotated in MT-YOLOv6 format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


